# discord-bot
discord bot with everything you need made in java

Adding this incase you've gotten a gateway connection throttle. This is likely caused due to new implementations in the Discord API. 
To get past this, go into your bot in your developer portal and enable both "Privileged Gateway Intents" checkmarks. 
