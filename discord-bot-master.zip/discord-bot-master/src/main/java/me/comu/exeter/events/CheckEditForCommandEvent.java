package me.comu.exeter.events;

import net.dv8tion.jda.api.hooks.ListenerAdapter;

class CheckEditForCommandEvent extends ListenerAdapter {



}
