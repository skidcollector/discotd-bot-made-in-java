package me.comu.exeter.util;

public class Products {

    public final static int SALE = 50;

    public static int NITRO_CODE_STOCK = 37;

    public final static int NITRO_CODE = 1000000;
    public final static int CUSTOM_ROLE = 25000;
    public final static int HOISTED_ROLE = 50000;
    public final static int CUSTOM_VC = 10000;
    public final static int VC_PERMS = 5000;
    public final static int STAFF_ROLE = 500000;

    public final static String NITRO_CODE_ID = "x-T62A";
    public final static String CUSTOM_ROLE_ID = "x-mK2h";
    public final static String HOISTED_ROLE_ID = "x-2tIM";
    public final static String CUSTOM_VC_ID = "x-N2xf";
    public final static String VC_PERMS_ID = "x-68dH";
    public final static String STAFF_ROLE_ID = "x-jT59";



}
