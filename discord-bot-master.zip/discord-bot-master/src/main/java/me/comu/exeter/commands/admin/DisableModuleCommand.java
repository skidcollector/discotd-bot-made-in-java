package me.comu.exeter.commands.admin;

class DisableModuleCommand {
}
