package me.comu.exeter.commands.marriage;

class CuddleCommand {
}
